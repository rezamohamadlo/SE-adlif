# Complementary mechanisms study v2: speaker-disjoint discovery

Effective user correction: 2026-11-11. Supersedes the discovery order in
[v1](complementary-mechanisms-study-v1.md); preserves its evidence. The full
objective remains two complementary ideas, Baseline -> A -> A+B, with a final
four-arm ablation. Existing `runner.py`/`run.py` remain the entry points.
The original study request explicitly authorizes the agent to launch, resume
and safely stop its own study jobs, overriding the repository's default
user-launch-only rule for this study. Unrelated processes remain protected.
The plan-update turn launched no training. No commit/push is authorized.

## Primary endpoint and protocol separation

Weak generalization, especially to unseen SHD speakers, is the central problem.
Random-split SHD* validation is no longer the sole idea-selection criterion.
The primary **development** endpoint is clean held-out-speaker accuracy, with
validation loss and learning curves as supporting evidence. A smaller
train/validation gap alone is not success. Final success still requires matched
ordinary-inference official-test accuracy; no test result selects ideas.

The earlier request for exploratory official-test evaluation is superseded by
the latest instruction to keep official tests outside this loop. No official
test evaluation was performed before this change. Speaker-development
checkpoints are explicitly ineligible as canonical SHD* test evidence.

## Frozen speakers and sample indices

Only `data/SHDWrapper/shd_train.h5` is read to create and verify these splits.
Both manifests were frozen before any v2 candidate evaluation; they include
original HDF5 row indices, source SHA-256, per-class counts and fingerprints.
There is no performance-dependent pair selection or fallback.

| Role | Training speakers | Validation speakers | Training / validation recordings |
|---|---|---|---:|
| Reused development pair | 1,2,6,7,8,9,10,11 | 0,3 | 6,521 / 1,635 |
| Predefined pair sensitivity | 0,1,2,3,7,8,9,11 | 6,10 | 6,920 / 1,236 |

For both pairs, speaker and recording intersections are empty, train+validation
exhaust the 8,156 official training rows, and each side covers all 20 classes.
Primary 0/3 has extensive historical tuning exposure and is labelled
development, not independent confirmation. Secondary 6/10 was fixed without
looking at candidate performance; it is a pair-sensitivity diagnostic, not
patient/speaker-population proof. No search for a better pair is permitted.

Only shortlisted methods plus the matched baseline may enter the secondary
pair, enforced by `SHORTLIST.json`. They **start fresh**: weights learned on
the primary pair include speakers 6/10 and must not be reused there. Likewise,
the earlier canonical random-split checkpoints saw many rows from each held-out
pair. Their use as unseen-speaker validation weights is prohibited. An exposure
audit is beside the new manifests.

## Initial mechanisms and matched conditions

- **Baseline:** unchanged two-layer SE-adLIF.
- **A001:** channel-specific causal residual FIR before projection, lags
  1,2,4,8 frames, zero-initialized identity. The v1 diagnostic found learned
  constant-input gain around 2.45, so this must not be called pure delay
  learning; held-out speaker performance, not the old random-split peak,
  determines whether it advances.
- **B001:** training-only independent 10% event deletion before the filter,
  hypothesized to reduce rate/gain reliance. A+B is compared with A, and the
  later B-only arm identifies generic augmentation benefits. This is not a
  novelty claim: [EventDrop, IJCAI 2021](https://ijcai.org/proceedings/2021/97)
  is prior art for event removal. Here deletion is binomial per event in count
  bins, rather than entire occupied-bin deletion; its combination with this
  FIR and the matched SE control is a new hypothesis relative to previous
  DTH/LG-DTH augmentation combinations. There is no assurance it will help.

All compared arms use the same frozen pair and indices, training seed42,
training/validation batches1024, LR0.01, Adam, dropout0.15, 32-bit/high matmul
precision, preprocessing, full300epoch schedule metadata and screening ceiling.
Paper baseline inheritance remains authoritative; split/batch/augmentation
deviations are explicit. Historical controls do not match this entire factorial
setup and are not reused. No pretrained or canonical weights initialize v2.

The initial shared ceiling is30 completed epochs. Extend technically sound,
improving or inconclusive comparisons to75 **for all compared arms**; do not
fully train every proposal under both protocols. Initial practical screen
threshold is +0.50 pp clean held-out-speaker accuracy (A-Baseline and A+B-A),
supported by loss/stability. This is a decision rule, not significance evidence.
If A fails but A+B improves, do not assume complementarity; inspect B-only and
revise the hypothesis. Negative pair sensitivity or dataset transfer is retained.

The old frame-warp augmentation operated on minimum-padded sequences, so it
could change artificial quiet duration. It is not used here. B001 never warps
time or changes tensor length/masks; padding zeros remain zeros, ECG negative
end markers remain unchanged, and validation/inference are clean. Augmentation
is drawn afresh during each training forward, outside deterministic caching.
No physical duration is inferred from the last nonzero frame.

## Revised stage order

0. Audit actual active jobs and preserve v1 canonical evidence. Freeze both
   training-only speaker manifests and verify overlap/class coverage.
1. Fresh primary 0/3 development: Baseline, A and A+B, seed42, matched30epoch
   screen; extend the same comparison to75 only when justified.
2. Fresh secondary 6/10 pair-sensitivity check: baseline and **only shortlisted**
   candidates, one predefined pair and matching budgets. No weights cross pairs.
3. Check promising mechanisms on SSC official validation: calibrated matched
   control/candidates, seed42, 10->40 epochs. Investigate regressions before B
   investment or broad replication. Preserve all unsuccessful outcomes.
4. Check ECG with verified established row separation/labels/masks: matched
   seed42, 50->100 when justified, full400 only for frozen comparisons. Patient
   IDs are absent, so patient independence is not claimed.
5. Freeze A, B, settings, practical test thresholds and final evaluation plan.
   If necessary, revise mechanisms using development evidence, never tests.
6. Run the frozen four-arm **canonical SHD*** comparison on its own random
   20% validation split, split seed42, full300epoch budget. Train those weights
   on that canonical split; do not relabel/reuse speaker-development weights.
   Complete matching four-arm SSC40/ECG400 evidence. B-only is mandatory.
7. Replicate frozen comparisons with training seeds123,456, preserving split42
   where applicable. No test-driven idea selection; additional seeds if needed.
8. Evaluate official tests once under the frozen ordinary-inference plan;
   report all datasets, train/validation/test metrics, paired differences,
   interaction, mean/sample SD, uncertainty, paper deltas and measured costs.

Speaker-development and canonical results remain in separate roots and tables.
Never subtract a speaker-validation score from the paper's SHD* test mean.
All earlier generalization, uncertainty, staging, calibration, cost and
checkpoint-safety obligations in v1 remain in force where not superseded here.

## Existing processes and evidence at correction

### Current bounded-stage audit (2026-11-11)

The live launcher uses
`config/studies/complementary_transfer_A002_gain_v1.yaml`: fresh Baseline and
gain-only A002 on SSC, training seed42, official SSC validation, batch1024,
LR0.006, a10epoch ceiling within the40epoch schedule, and tests disabled.
The baseline's first completed epoch is recorded in the launcher log. This is
stage3 cross-dataset development, not random-split SHD*, speaker-holdout SHD,
or official-test evidence. Preserve the process and let this bounded stage
finish; this audit does not launch, resume, stop or extend training.

The active plan remains the stage order above. Baseline/A/A+B comparisons for
subsequent mechanisms must use fresh, matched speaker-development runs; the
gain-only diagnostic does not replace the required A+B and final B-only arms.
Historical controls require an exact split and configuration match, including
preprocessing, optimization, budget and checkpoint-selection rules. Previously
exposed speaker weights cannot serve as clean held-out-speaker controls.

Audit evidence: live launcher and training-child command lines, and
`results/experiments/complementary_speaker_dev_v2/a002_ssc_stage010_stdout.log`.
Progress is a timestamped observation, not a claim that the queue has completed.

### Conditional mechanism check after transfer

If the full SSC40epoch screen gives no practical improvement, do not extend it
past its declared budget or invest heavily in B. First run the preregistered
gain-only control on the **same frozen primary0/3development pair**:
`config/studies/complementary_gain_control_A001_v1.yaml`. It compares fresh
Baseline/FIR/gain-only at seed42 and30epochs, sharing all optimization and
preprocessing settings. The gain-only mode retains four coefficients per
channel and identity initialization, but mixes no temporal history. It tests
an interpretation of A rather than establishing a new timing-specific result.
The secondary pair is not a tuning target, and no favorable pair is sought.

SSC findings, including regressions, remain in the cumulative evidence. ECG
remains explicitly pending; this diagnostic does not replace a dataset in the
final SHD*/SSC/ECG assessment. No two-dataset improvement is claimed from SHD
development alone. Source changes for this control occur only after the active
transfer queue closes and its source, checkpoints and metrics are preserved.

The canonical v1 seed42 baseline/A001 each completed75 epochs. They are
historical random-split development evidence, not unseen-speaker controls.
The attempted150epoch launcher exited **before training** with
`Source revision changed; refusing to resume this study`. No model training was
active at the audit, so no training was stopped or discarded. Source guards
were not bypassed. The ongoing SSC training/validation-only download is
preserved; it is not a GPU training job. No unrelated job is altered.

## Artifacts and execution

The gain control can advance as **A002 input conditioning** only through the
same development gates; do not rebrand it as a timing mechanism. Its follow-up
uses `config/studies/complementary_transfer_A002_gain_v1.yaml`, with fresh
matched controls under `transfer_A002_gain_v1/`. SSC uses10->40epochs,
official validation, batch1024/eight workers/LR0.006; ECG uses50->100staging
before any frozen400epoch comparison, its established row validation,
batch256/LR0.01 and separate calibration. Practical screening thresholds and
all qualifications are preregistered in the results root before training.
Keep the failed SSC FIR transfer and all earlier source versions as evidence.

Study root: `results/experiments/complementary_speaker_dev_v2/`.
Configs: `config/studies/complementary_speaker_dev_v2.yaml` and
`config/studies/complementary_speaker_sensitivity_v2.yaml`.
Cross-dataset A001 transfer uses the separate
`config/studies/complementary_transfer_A001_v2.yaml`, with outputs under
`results/experiments/complementary_speaker_dev_v2/transfer_A001/`.
Its SSC protocol uses official training/validation, calibrated train/validation
batch1024, LR0.006 unchanged, eight persistent workers, and opt-in spawn-safe
preprocessing verified to preserve tensors, labels and masks exactly. It does
not apply an SHD speaker split to SSC. Main transfer weights start fresh;
historical SSC weights were used only for numerical batch calibration.
Calibration evidence and the pre-launch advancement rule are beside the study
root. Do not use the primary/sensitivity SHD configs to launch transfer jobs.
The completed SHD source snapshot is retained; changes for the separate transfer
stage never bypass historical resume guards. Dataset defaults remain unchanged.
Each pair has its own frozen manifest, cache identity and seed outputs.
Keep STATUS, registry, epoch CSV/JSONL, best/last and stage snapshots, resolved
configs and cumulative reports. Source/provenance guards stay enabled; freeze
implementation before launching a queue and diagnose incompatible revisions
rather than modifying historical records. Every direct resume also verifies
the checkpoint belongs to the same run, split and configuration.

```powershell
.\.ven\Scripts\python.exe runner.py --models SE_adLIF FIR_SE_adLIF FIR_THIN_SE_adLIF --datasets SHD --seeds 42 --study-file config/studies/complementary_speaker_dev_v2.yaml --stage-ceiling 30
```

This is the command for the authorized bounded discovery screen, not the final
paper comparison or test evaluation. The local checkout has `.ven`; use
`.venv` instead on a machine with that environment directory. Append `--dry-run`
for the non-training preflight that has been verified locally.

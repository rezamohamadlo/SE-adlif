import math
import hashlib
import json
import re
from typing import Optional

import h5py
import numpy as np
import torch
import torch.utils.data
from torch.utils.data import DataLoader
import pytorch_lightning as pl
from datasets.utils.pad_tensors import PadTensors
from datasets.utils.transforms import TakeEventByTime, AddNoiseByproportion, Flatten
from datasets.utils.diskcache import DiskCachedDataset
import tonic
from tonic.datasets.hsd import SHD
from torch.utils import data
from tonic.transforms import ToFrame
from tonic.io import make_structured_array
import hydra
import os
""" The following class is a wrapper for the SHD dataset with a block_idx (see Readme.md) """


class SHDWrapper(SHD):
    dataset_name = "SHD"

    def __init__(
        self,
        save_to: str,
        train: bool = True,
        transform = None,
        target_transform = None,
        ignore_first_timesteps: int = 10,
    ):
        super().__init__(save_to, train, transform, target_transform)
        self.ignore_first_timesteps = ignore_first_timesteps

    def __getitem__(self, index):
        # SHD timestamps are stored as float16 seconds.  Multiplying that type
        # by 1e6 overflows before Tonic can cast it to the integer event dtype.
        # Widen before converting seconds to microseconds.
        with h5py.File(
            os.path.join(self.location_on_system, self.data_filename), "r"
        ) as file:
            events = make_structured_array(
                file["spikes/times"][index].astype(np.float64) * 1e6,
                file["spikes/units"][index],
                1,
                dtype=self.dtype,
            )
            target = file["labels"][index].astype(int)
        if self.transform is not None:
            events = self.transform(events)
        if self.target_transform is not None:
            target = self.target_transform(target)
        block_idx = torch.ones((events.shape[0],), dtype=torch.int64)
        block_idx[:self.ignore_first_timesteps] = 0
        return events, target, block_idx


class SHDLDM(pl.LightningDataModule):
    def __init__(
        self,
        data_path: str,
        spatial_factor: float = 0.12,
        time_factor: float = 1e-3,
        window_size: float = 5.0,
        split_percent: float = 0.8,
        batch_size: int = 32,
        num_workers: int = 1,
        pad_to_min_size: int = None,
        bias_for_test_set: float = 0.0,
        test_bias_variant: str = "bias",
        name: str = None,  # for hydra
        num_classes: int = 20,  # for hydra
        validate_on=0.05,
        additional_test_set_validation: bool = False,
        random_seed=42,
        ignore_first_timesteps: int = 10,
        cache_namespace: str = None,
        speaker_split_manifest: str = None,
        speaker_split_fingerprint: str = None,
        train_augmentation: dict = None,
        validation_only_data: bool = False,
        validation_batch_size: int = None,
    ) -> None:
        super().__init__()
        # workaround in order to use the same training loop
        # for classification and context processing
        
        if validate_on == 'speaker_holdout':
            from project_paths import local_path
            from datasets.shd_speaker_split import load_manifest, PROTOCOL, DEVELOPMENT_PROTOCOL
            data_path = str(local_path(data_path))
            allowed_cache = ('shd_speaker_augmented_v1' if train_augmentation is not None else PROTOCOL)
            if (cache_namespace not in (allowed_cache, DEVELOPMENT_PROTOCOL) or not speaker_split_manifest
                    or not speaker_split_fingerprint or random_seed != 42
                    or additional_test_set_validation):
                raise ValueError('Speaker holdout requires its frozen manifest/cache and split seed 42; no test validation')
            self.speaker_split = load_manifest(speaker_split_manifest, data_path, speaker_split_fingerprint)
            if cache_namespace==DEVELOPMENT_PROTOCOL:
                if (not validation_only_data or train_augmentation is not None
                        or self.speaker_split['protocol']!=DEVELOPMENT_PROTOCOL):
                    raise ValueError('Speaker development requires its train-only manifest and clean dataset transforms')
            elif self.speaker_split['protocol']!=PROTOCOL:
                raise ValueError('Historical and new speaker protocols cannot share a cache namespace')
        elif speaker_split_manifest is not None or speaker_split_fingerprint is not None:
            raise ValueError('Speaker manifest requires validate_on=speaker_holdout')
        if train_augmentation is not None and validate_on != 'speaker_holdout':
            raise ValueError('SHD train augmentation requires the opt-in speaker holdout protocol')
        self.train_augmentation = None
        if train_augmentation is not None:
            from datasets.shd_augmentation import SHDFrameAugmentation
            self.train_augmentation = SHDFrameAugmentation(
                **train_augmentation, ignore_first_timesteps=ignore_first_timesteps,
                pad_to_min_size=pad_to_min_size)

        if not os.path.isabs(data_path):
            cwd = hydra.utils.get_original_cwd()
            data_path = os.path.abspath(os.path.join(cwd, data_path))
            
        self.data_path = data_path
        self.cache_path = data_path + "/cache/SHD"
        # Opt-in isolation preserves legacy paths and prevents subset-local
        # cache indices from referring to different samples after split changes.
        if cache_namespace is not None:
            if not re.fullmatch(r"[A-Za-z0-9_-]+", cache_namespace):
                raise ValueError("cache_namespace must contain only letters, digits, '_' or '-'")
            signature_fields = dict(
                spatial_factor=spatial_factor, time_factor=time_factor,
                window_size=window_size, pad_to_min_size=pad_to_min_size,
                validate_on=validate_on, random_seed=random_seed,
                ignore_first_timesteps=ignore_first_timesteps,
                bias_for_test_set=bias_for_test_set, test_bias_variant=test_bias_variant,
            )
            if speaker_split_fingerprint is not None:
                signature_fields['speaker_split_fingerprint'] = speaker_split_fingerprint
            signature = json.dumps(signature_fields, sort_keys=True)
            digest = hashlib.sha256(signature.encode()).hexdigest()[:16]
            self.cache_path = os.path.join(self.cache_path, f"{cache_namespace}_{digest}")
            if speaker_split_fingerprint is not None:
                self.cache_path = os.path.join(self.cache_path, speaker_split_fingerprint)
        self.spatial_factor = spatial_factor
        self.time_factor = time_factor
        self.window_size = window_size
        self.split_percent = split_percent
        self.batch_size = batch_size
        self.validation_batch_size = validation_batch_size or batch_size
        self.num_workers = num_workers
        self.collate_fn = PadTensors()
        self.validate_on = validate_on
        self.additional_test_set_validation = additional_test_set_validation
        self.random_seed = random_seed
        self.bias_for_test_set = bias_for_test_set
        self.test_bias_variant = test_bias_variant
        # used for the random position signal task
        # the transformation will add zeros at the right side
        # of a length based on the original size of the data-sample
        self.pad_to_min_size = pad_to_min_size
        self.ignore_first_timesteps = ignore_first_timesteps

        sensor_size = SHDWrapper.sensor_size
        sensor_size = (
            int(math.ceil(sensor_size[0] * self.spatial_factor)),
            int(math.ceil(sensor_size[1]) * self.spatial_factor),
            sensor_size[2],
        )

        self.input_size = math.prod(sensor_size)
        self.output_size = 20
        self.class_weights = torch.ones(
            size=(self.output_size,),
        )
        self.sensor_size = sensor_size
        _event_to_tensor = ToFrame(
            sensor_size=sensor_size, time_window=self.window_size
        )

        def event_to_tensor(x):
            return torch.from_numpy(_event_to_tensor(x)).float()

        def pad_to_min_size(x):
            if self.pad_to_min_size is None:
                return x
            elif x.shape[0] >= self.pad_to_min_size:
                return x
            else:
                return torch.cat(
                    [
                        x,
                        torch.zeros(
                            (self.pad_to_min_size - x.shape[0], x.shape[1], x.shape[2])
                        ),
                    ],
                    dim=0,
                )

        def add_bias_to_test_data(x, level):
            return x + level * torch.mean(x)

        if test_bias_variant == "noise":
            test_transform_list = [
                AddNoiseByproportion(
                    self.bias_for_test_set,
                    is_frame=False,
                    sensor_size=(sensor_size[0], 1, 1),
                ),
                tonic.transforms.Downsample(
                    time_factor=self.time_factor, spatial_factor=self.spatial_factor
                ),
                event_to_tensor,
                # pooling,
                pad_to_min_size,
                Flatten(),
            ]
        else:
            test_transform_list = [
                tonic.transforms.Downsample(
                    time_factor=self.time_factor, spatial_factor=self.spatial_factor
                ),
                event_to_tensor,
                # pooling,
                pad_to_min_size,
                Flatten(),
            ]

        self.static_data_transform_train_val = tonic.transforms.Compose(
            [
                tonic.transforms.Downsample(
                    time_factor=self.time_factor, spatial_factor=self.spatial_factor
                ),
                event_to_tensor,
                pad_to_min_size,
                Flatten(),
            ]
        )  # noqa

        # This is used for the noisy experiments
        if test_bias_variant == "bias":
            self.static_data_transform_test = tonic.transforms.Compose(
                test_transform_list
                + [lambda x: add_bias_to_test_data(x, self.bias_for_test_set)]
            )
        else:
            self.static_data_transform_test = tonic.transforms.Compose(
                test_transform_list
            )

        self.generator = torch.Generator().manual_seed(self.random_seed)
        if validation_only_data and (self.validate_on == 'test' or additional_test_set_validation):
            raise ValueError('Training-only data access forbids official test validation')
        if not validation_only_data:
            self.data_test = SHDWrapper(
                save_to=self.data_path,
                transform=self.static_data_transform_test,
                train=False,
                ignore_first_timesteps=self.ignore_first_timesteps,
            )

        if self.validate_on == 'speaker_holdout':
            from datasets.shd_speaker_split import check_loader
            self.train_val_ds = SHDWrapper(
                save_to=self.data_path, transform=self.static_data_transform_train_val,
                train=True, ignore_first_timesteps=self.ignore_first_timesteps)
            check_loader(self.train_val_ds, self.speaker_split)
            self.data_train = torch.utils.data.Subset(
                self.train_val_ds, self.speaker_split['subsets']['train']['indices'])
            self.data_val = torch.utils.data.Subset(
                self.train_val_ds, self.speaker_split['subsets']['validation']['indices'])

        # validate on the test set
        elif self.validate_on == "test":
            self.data_train = SHDWrapper(
                save_to=self.data_path,
                transform=self.static_data_transform_train_val,
                train=True,
                ignore_first_timesteps=self.ignore_first_timesteps,
            )

            self.data_val = SHDWrapper(
                save_to=self.data_path,
                transform=self.static_data_transform_train_val,
                train=False,
                ignore_first_timesteps=self.ignore_first_timesteps,
            )

        # validate on a percentage of the training set
        elif isinstance(self.validate_on, float):
            self.train_val_ds = SHDWrapper(
                save_to=self.data_path,
                transform=self.static_data_transform_train_val,
                train=True,
                ignore_first_timesteps=self.ignore_first_timesteps,
            )
            valid_len = math.floor(len(self.train_val_ds) * self.validate_on)
            self.data_train, self.data_val = torch.utils.data.random_split(
                self.train_val_ds,
                [len(self.train_val_ds) - valid_len, valid_len],
                generator=self.generator,
            )
        else:
            raise ValueError(f"validate_on {self.validate_on} is not valid")

    def prepare_data(self):
        pass
        

    def setup(self, stage: Optional[str] = None) -> None:
        pass

    def train_dataloader(self):
        return DataLoader(
            DiskCachedDataset(self.data_train, self.cache_path + "/train",
                              full_transform=self.train_augmentation),
            shuffle=True,
            pin_memory=True,
            batch_size=self.batch_size,
            drop_last=True,
            collate_fn=self.collate_fn,
            num_workers=self.num_workers,
            persistent_workers=self.num_workers > 0,
        )

    def val_dataloader(self):
        val_dataloader = DataLoader(
            DiskCachedDataset(self.data_val, self.cache_path + "/val"),
            shuffle=False,
            pin_memory=True,
            batch_size=self.validation_batch_size,
            drop_last=False,
            collate_fn=self.collate_fn,
            num_workers=self.num_workers,
            persistent_workers=self.num_workers > 0,
        )

        if self.additional_test_set_validation:
            return [
                val_dataloader,
                DataLoader(
                    DiskCachedDataset(self.data_test, self.cache_path + "/test",),
                    shuffle=False,
                    pin_memory=True,
                    batch_size=self.batch_size,
                    drop_last=False,
                    collate_fn=self.collate_fn,
                    num_workers=self.num_workers,
                    persistent_workers=self.num_workers > 0,
                ),
            ]
        else:
            return val_dataloader

    def test_dataloader(self):
        return DataLoader(
            DiskCachedDataset(self.data_test, self.cache_path + "/test"),
            pin_memory=True,
            shuffle=False,
            batch_size=self.batch_size,
            drop_last=False,
            collate_fn=self.collate_fn,
            num_workers=self.num_workers,
            persistent_workers=self.num_workers > 0,
        )

    def predict_dataloader(self):
        return DataLoader(
            DiskCachedDataset(self.data_test, self.cache_path + "/test"),
            shuffle=False,
            batch_size=self.batch_size,
            pin_memory=True,
            drop_last=False,
            collate_fn=self.collate_fn,
            num_workers=self.num_workers,
            persistent_workers=self.num_workers > 0,
        )

import csv
import copy
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

import contextlib
import io
import torch

import runner as full_runner


class FullRunnerTests(unittest.TestCase):
    def test_legacy_ssc_ecg_require_identical_effective_settings(self):
        for dataset in ('SSC', 'ECG'):
            current = full_runner.build_plan('DTH_SE_adLIF', seeds=(42,), datasets=(dataset,))[0]['config']
            legacy = copy.deepcopy(current)
            for key in ('paper_baseline', 'paper_baseline_version',
                        'paper_baseline_dataset', 'paper_baseline_deviations'):
                legacy.pop(key)
            legacy['evaluation_protocol'] = 'controlled_v2'
            self.assertEqual(full_runner.matches_paper_baseline(legacy, current, dataset), dataset == 'ECG')
            for key, value in [('early_stopping', True), ('n_epochs', 1),
                               ('batch_size', 1), ('lr', .5), ('random_seed', 123)]:
                changed = copy.deepcopy(legacy)
                changed[key] = value
                with self.subTest(dataset=dataset, key=key):
                    self.assertFalse(full_runner.matches_paper_baseline(changed, current, dataset))
            changed = copy.deepcopy(legacy)
            changed['dataset']['num_workers'] = 8
            self.assertFalse(full_runner.matches_paper_baseline(changed, current, dataset))

    def test_legacy_shd_baseline_match_preserves_provenance_and_resume(self):
        item = full_runner.build_plan('LG_DTH_SE_adLIF', seeds=(123,), datasets=('SHD',))[0]
        legacy = copy.deepcopy(item['config'])
        for key in ('paper_baseline', 'paper_baseline_version',
                    'paper_baseline_dataset', 'paper_baseline_deviations'):
            legacy.pop(key)
        legacy['evaluation_protocol'] = 'controlled_v2_custom_b134d147776c'
        legacy['dataset'].pop('additional_test_set_validation')
        directory = item['directory']
        (directory / 'ckpt').mkdir(parents=True)
        (directory / 'ckpt/last.ckpt').touch()
        manifest = directory / 'FULL_RUN_CONFIG.json'
        original_text = json.dumps(legacy)
        manifest.write_text(original_text, encoding='utf-8')
        plan = full_runner.build_plan('LG_DTH_SE_adLIF', seeds=(123, 456), datasets=('SHD',))
        self.assertEqual([x['status'] for x in plan], ['resume', 'new'])
        self.assertEqual(plan[0]['compatibility']['original_config'], legacy)
        self.assertIn('ckpt_path=', plan[0]['overrides'][-1])
        self.assertFalse((directory / 'PAPER_BASELINE_COMPATIBILITY.json').exists())
        with patch.object(full_runner.subprocess, 'run') as train, patch.object(full_runner, 'write_aggregate'):
            train.return_value.returncode = 0
            full_runner.run('LG_DTH_SE_adLIF', seeds=(123,), datasets=('SHD',))
        self.assertEqual(manifest.read_text(encoding='utf-8'), original_text)
        audit = json.loads((directory / 'PAPER_BASELINE_COMPATIBILITY.json').read_text())
        self.assertEqual(audit['resolved_config'], item['config'])
        with patch.object(full_runner.subprocess, 'run') as train, patch.object(full_runner, 'write_aggregate'):
            full_runner.run('LG_DTH_SE_adLIF', seeds=(123,), datasets=('SHD',))
            train.assert_not_called()
        for key, value in [('lr', .02), ('n_epochs', 301), ('early_stopping', True),
                           ('random_seed', 42), ('batch_size', 512),
                           ('evaluation_protocol', 'unknown_protocol')]:
            changed = copy.deepcopy(legacy)
            changed[key] = value
            manifest.write_text(json.dumps(changed), encoding='utf-8')
            with self.subTest(key=key), self.assertRaisesRegex(ValueError, 'Configuration changed'):
                full_runner.build_plan('LG_DTH_SE_adLIF', seeds=(123,), datasets=('SHD',))
        for key, value in [('random_seed', 123), ('validate_on', .1),
                           ('window_size', 8), ('additional_test_set_validation', True)]:
            changed = copy.deepcopy(legacy)
            changed['dataset'][key] = value
            manifest.write_text(json.dumps(changed), encoding='utf-8')
            with self.subTest(dataset_key=key), self.assertRaisesRegex(ValueError, 'Configuration changed'):
                full_runner.build_plan('LG_DTH_SE_adLIF', seeds=(123,), datasets=('SHD',))
        changed = copy.deepcopy(legacy)
        changed['l1']['local_slow_enabled'] = False
        manifest.write_text(json.dumps(changed), encoding='utf-8')
        with self.assertRaisesRegex(ValueError, 'Configuration changed'):
            full_runner.build_plan('LG_DTH_SE_adLIF', seeds=(123,), datasets=('SHD',))

    def test_resume_flag_defaults_to_resume_and_fresh_runs_never_overwrite(self):
        item = full_runner.build_plan('FP_SE_adLIF', seeds=(42,), datasets=('SSC',), resume=0)[0]
        self.assertEqual(item['status'], 'new')
        directory = item['directory']
        directory.mkdir(parents=True)
        (directory / 'FULL_RUN_CONFIG.json').write_text(json.dumps(item['config']), encoding='utf-8')
        (directory / 'ckpt').mkdir()
        (directory / 'ckpt/last.ckpt').touch()
        self.assertEqual(full_runner.build_plan('FP_SE_adLIF', seeds=(42,), datasets=('SSC',))[0]['status'], 'resume')
        with self.assertRaisesRegex(ValueError, 'empty output directory'):
            full_runner.build_plan('FP_SE_adLIF', seeds=(42,), datasets=('SSC',), resume=0)
        with patch.object(full_runner, 'build_plan', return_value=[]) as build:
            with contextlib.redirect_stdout(io.StringIO()):
                full_runner.main(['--models', 'FP_SE_adLIF', '--dry-run'])
            self.assertEqual(build.call_args.args[-1], 1)

    def test_cli_overrides_are_applied_and_isolated(self):
        original = full_runner.EVALUATION
        captured = []
        build = full_runner.build_plan
        def inspect(*args):
            plan = build(*args)
            captured.extend(plan)
            return plan
        with patch.object(full_runner, 'build_plan', side_effect=inspect):
            with contextlib.redirect_stdout(io.StringIO()):
                full_runner.main(['--models', 'SE_adLIF', '--datasets', 'SHD',
                                  '--seeds', '42', '--epochs', '12', '--batch-size', '32',
                                  '--lr', '0.002', '--early-stopping', 'false', '--dry-run'])
        cfg = captured[0]['config']
        self.assertEqual(cfg['n_epochs'], 12)
        self.assertEqual(cfg['batch_size'], 32)
        self.assertEqual(cfg['dataset']['batch_size'], 32)
        self.assertEqual(cfg['lr'], .002)
        self.assertFalse(cfg['early_stopping'])
        self.assertEqual(cfg['dataset']['validate_on'], .2)
        self.assertIn('experiments', captured[0]['directory'].parts)
        self.assertIn('_custom_', cfg['evaluation_protocol'])
        self.assertIs(full_runner.EVALUATION, original)

    def test_cli_selects_models_datasets_and_seeds_without_training(self):
        with patch.object(full_runner, 'run') as train:
            with contextlib.redirect_stdout(io.StringIO()) as output:
                full_runner.main(['--models', 'SE_adLIF', 'DTH_SE_adLIF',
                                  '--datasets', 'SHD', '--seeds', '123', '--dry-run'])
            train.assert_not_called()
            self.assertIn('Validated 2 runs', output.getvalue())
            self.assertNotIn(' SSC ', output.getvalue())
            self.assertNotIn(' ECG ', output.getvalue())

    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        shutil.copytree(full_runner.ROOT / "config", self.root / "config")
        self.root_patch = patch.object(full_runner, "ROOT", self.root)
        self.root_patch.start()
        self.addCleanup(self.root_patch.stop)

    def test_all_model_plans(self):
        for model in ("SE_adLIF", "DTH_SE_adLIF", "MT_SE_adLIF", "DA_SE_adLIF", "MR_SE_adLIF", "FP_SE_adLIF"):
            plan = full_runner.build_plan(model)
            self.assertEqual([(x['dataset'], x['seed']) for x in plan],
                             [(d, s) for d in ("SHD", "SSC", "ECG") for s in (42,123,456)])
            self.assertEqual([x['config']['batch_size'] for x in plan[::3]], [256,256,64])
            self.assertEqual([x['config']['n_epochs'] for x in plan[::3]], [300,40,400])
            self.assertEqual([x['config']['early_stopping'] for x in plan[::3]],
                             [False, False, False])
            self.assertTrue(all(x['config']['early_stopping_patience'] == 50 for x in plan))
            self.assertTrue(all(x['config']['patience'] == 9999 for x in plan))
            self.assertTrue(all(x['config']['evaluation_protocol'] ==
                                ('ssc_mean_loss_v1' if x['dataset'] == 'SSC' else 'paper_classification_v1')
                                for x in plan))
            self.assertEqual([x['config']['lr'] for x in plan[::3]], [.01, .006, .01])
            for item in plan[:3]:
                self.assertEqual(item['config']['dataset']['validate_on'], .2)
                self.assertEqual(item['config']['dataset']['random_seed'], 42)
                self.assertEqual(item['config']['dataset']['cache_namespace'], 'controlled_v2')
            for item in plan[6:]:
                self.assertEqual(item['config']['dataset']['random_seed'], 42)
                self.assertEqual(item['config']['dataset']['valid_fraction'], .05)
        with self.assertRaises(ValueError):
            full_runner.build_plan("../bad")
        with self.assertRaises(ValueError):
            full_runner.build_plan("MissingModel")

    def test_resume_skip_and_configuration_guard(self):
        item = full_runner.build_plan("MT_SE_adLIF")[0]
        directory = item['directory']
        directory.mkdir(parents=True)
        manifest = directory / "FULL_RUN_CONFIG.json"
        manifest.write_text(json.dumps(item['config']), encoding='utf-8')
        (directory / 'ckpt').mkdir()
        (directory / 'ckpt' / 'last.ckpt').touch()
        resumed = full_runner.build_plan("MT_SE_adLIF")[0]
        self.assertEqual(resumed['status'], 'resume')
        self.assertTrue(resumed['overrides'][-1].startswith('ckpt_path='))
        (directory / 'completed.txt').touch()
        self.assertEqual(full_runner.build_plan("MT_SE_adLIF")[0]['status'], 'complete')
        manifest.write_text('{}', encoding='utf-8')
        with self.assertRaises(ValueError):
            full_runner.build_plan("MT_SE_adLIF")

    def test_legacy_manifest_accepts_only_equivalent_new_defaults(self):
        item = full_runner.build_plan('FP_SE_adLIF', seeds=(42,), datasets=('SSC',))[0]
        directory = item['directory']
        directory.mkdir(parents=True)
        legacy = dict(item['config'])
        for key in ('init_ckpt_path', 'run_test', 'scheduler', 'scheduler_min_lr', 'gradient_clip_val'):
            legacy.pop(key)
        (directory / 'FULL_RUN_CONFIG.json').write_text(json.dumps(legacy), encoding='utf-8')
        (directory / 'ckpt').mkdir()
        (directory / 'ckpt/last.ckpt').touch()
        self.assertEqual(full_runner.build_plan('FP_SE_adLIF', seeds=(42,), datasets=('SSC',))[0]['status'], 'resume')
        legacy['scheduler'] = 'constant'
        (directory / 'FULL_RUN_CONFIG.json').write_text(json.dumps(legacy), encoding='utf-8')
        with self.assertRaises(ValueError):
            full_runner.build_plan('FP_SE_adLIF', seeds=(42,), datasets=('SSC',))

    def test_two_stage_seed_selection_preserves_config_and_paths(self):
        for model in ('DTH_SE_adLIF', 'DA_SE_adLIF', 'MR_SE_adLIF'):
            complete = full_runner.build_plan(model)
            first = full_runner.build_plan(model, seeds=(42, 42))
            second = full_runner.build_plan(model, seeds=(123, 456))
            self.assertEqual(len(first), 3)
            self.assertEqual(len(second), 6)
            self.assertEqual({x['seed'] for x in first}, {42})
            self.assertEqual({x['seed'] for x in second}, {123, 456})
            for item in first + second:
                original = next(x for x in complete if x['directory'] == item['directory'])
                self.assertEqual(item['config'], original['config'])
                self.assertEqual(item['overrides'], original['overrides'])
        for seeds in ((), (0,), (True,)):
            with self.assertRaises(ValueError):
                full_runner.build_plan('DTH_SE_adLIF', seeds=seeds)

    def test_aggregate_only_completed_seeds(self):
        for seed, value, complete in ((42, .90, True), (123, .92, True), (456, .99, False)):
            directory = full_runner.result_root('MT_SE_adLIF') / 'SHD' / f'seed_{seed}'
            metrics = directory / 'logs/mlp_snn/version_0/metrics.csv'
            metrics.parent.mkdir(parents=True)
            with metrics.open('w', newline='') as stream:
                writer = csv.DictWriter(stream, fieldnames=['test_acc'])
                writer.writeheader()
                writer.writerow({'test_acc': value})
            if complete:
                (directory / 'completed.txt').touch()
        full_runner.write_aggregate('MT_SE_adLIF')
        text = (full_runner.result_root('MT_SE_adLIF') / 'RESULTS.md').read_text(encoding='utf-8')
        self.assertIn('| SHD* | 90.00% | 92.00% | pending | 2 | 91.00% ± 1.41% |', text)

    def test_mr_interval_isolation(self):
        first = full_runner.build_plan('MR_SE_adLIF', 2)[0]
        other = full_runner.build_plan('MR_SE_adLIF', 4)[0]
        self.assertNotEqual(first['directory'], other['directory'])
        self.assertIn('K_2', first['directory'].parts)
        for item in full_runner.build_plan('MR_SE_adLIF', 2):
            self.assertEqual(item['config']['l1']['adaptation_update_interval'], 2)
            self.assertEqual(item['config']['l2']['adaptation_update_interval'], 2)
        for k in (0, -1, True, 1.5):
            with self.assertRaises(ValueError):
                full_runner.build_plan('MR_SE_adLIF', k)

    def test_candidate_models_construct_on_each_dataset(self):
        from models.pl_module import MLPSNN
        from omegaconf import OmegaConf
        torch.manual_seed(42)
        for variant in ('SE_adLIF', 'DTH_SE_adLIF', 'DA_SE_adLIF', 'MR_SE_adLIF', 'FP_SE_adLIF'):
            for item in full_runner.build_plan(variant)[::3]:
                cfg = OmegaConf.create(item['config'])
                with contextlib.redirect_stdout(io.StringIO()):
                    model = MLPSNN(cfg)
                output = model(torch.randn(2, 14, cfg.l1.input_size)*5)
                self.assertEqual(output.shape, (2, 14, cfg.dataset.num_classes))
                output.square().mean().backward()
                self.assertTrue(torch.isfinite(model.l1.weight.grad).all())
                self.assertTrue(torch.isfinite(model.l2.weight.grad).all())


if __name__ == '__main__':
    unittest.main()
